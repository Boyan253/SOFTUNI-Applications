import { showView } from "./util.js"

const section = document.querySelector('#edit-movie')


function editPage(){
  showView(section)
}
